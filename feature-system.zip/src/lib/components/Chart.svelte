<script lang="ts">
  import { onMount, tick } from 'svelte';
  export let option: any | null = null;
  export let height: string = '320px';
  export let ariaLabel: string = 'chart';

  let el: HTMLDivElement;
  let chart: any;
  let echarts: any;

  const ensureHeight = () => {
    if (el && !el.style.height) el.style.height = height;
  };

  onMount(async () => {
    ensureHeight();
    await tick();
    echarts = await import('echarts');
    chart = echarts.init(el, undefined, { renderer: 'canvas' });

    const ro = new ResizeObserver(() => chart?.resize());
    ro.observe(el);

    if (option) chart.setOption(option);

    return () => {
      ro.disconnect();
      chart?.dispose();
    };
  });

  $: if (chart && option) chart.setOption(option, true);
</script>

<div bind:this={el} class="w-full rounded-xl border p-4" {ariaLabel} />
