# Feature System: Fast pages + backend-connected ECharts + forms (SvelteKit + Supabase)

This kit lets you add **a new page with an ECharts graph + a form** that writes to Supabase (with RLS) and updates the chart — in minutes.

## What you get
- **Generic `Chart.svelte`** wrapper (SSR-safe, resizes, initializes ECharts only on client).
- **Generator script** `scripts/new-feature.mjs` that scaffolds:
  - a Supabase migration (table + RLS policies + trigger)
  - a SvelteKit route with `+page.server.ts` (load + form actions)
  - a `+page.svelte` with form + live-updating chart
  - a small `zod` schema per feature (server-side validation)
  - an ECharts options builder for the feature
- **Radar example templates** out of the box.

> Keep your existing stack (SvelteKit, Supabase, ECharts, Vercel). This kit just automates the repetitive glue.

---

## Quick start

1) **Copy this folder** into your repo root.
```
feature-system/
  README_FEATURE_SYSTEM.md
  scripts/new-feature.mjs
  scripts/templates/...
  src/lib/components/Chart.svelte
```
If your repo uses `src/` at root, this matches your layout.

2) **Install deps** (if not already present):
```bash
npm i echarts zod
```

3) **Generate a new feature** (example: radar chart for KPIs):
```bash
node feature-system/scripts/new-feature.mjs radar kpis
```
This will create, by default:
- Supabase migration: `supabase/migrations/<timestamp>_add_kpis_table.sql`
- Route: `src/routes/(admin)/kpis/(menu)/+page.server.ts` and `+page.svelte`
- Schema: `src/lib/schemas/kpis.ts`
- Chart option builder: `src/lib/charts/kpisOption.ts`
- Form component: `src/lib/components/forms/KpisForm.svelte`

> You can pass optional flags: `--route "(admin)/analytics"` or `--table "kpi_charts"`

4) **Push the migration** to Supabase and seed if desired:
```bash
# link once
# supabase link --project-ref <your-project-ref>

supabase db push
# optionally add a seed row after push; see the TODO at the top of the generated migration
```

5) **Run the app**, log in as a user, open the new page and submit the form — the chart should update immediately.

---

## Conventions & shape

- Every feature table has:
  - `id uuid pk`, `user_id uuid` (FK auth.users), `tenant_id uuid`, `data jsonb`, `description text`,
  - RLS: authenticated users can see/insert/update their own rows (user_id match).
  - `updated_at` trigger.

- **JSON shape** for radar (default):
```ts
type RadarData = {
  title?: string;
  indicators: { name: string; max?: number }[];
  values: number[]; // length matches indicators
}
```

- **`Chart.svelte`** handles SSR safety: dynamic `echarts` import in `onMount`, a stable container height, and a `ResizeObserver` to keep the graph responsive.

- **Form workflow**:
  - `+page.svelte` uses `<form method="POST">` with SvelteKit `enhance` for progressive enhancement.
  - Server action validates with `zod`, **upserts** the row (by `user_id`), and returns the updated `data`.
  - The page sets the new option so the chart updates without a full reload.

---

## FAQ

**Q: My chart is blank.**
- Ensure the container has a height (we default to 320px).
- Ensure ECharts init only runs in the browser (`onMount`).
- Validate that the `values` length matches `indicators`.

**Q: Multi-tenant filtering?**
- We fetch `tenant_id` from `user_profiles` and write it on insert/update, but we do not filter by tenant for reads unless you want to. Add `.eq("tenant_id", ...)` in the server load if required.

**Q: Can I add other charts (bar/line)?**
- Yes. Duplicate the radar templates and change the `getOption()` builder to your chart type. Or extend the generator (simple switch-case).

**Q: How do I keep this safe?**
- All writes are validated with `zod`, and RLS ensures users can only access their own rows.

---

## Troubleshooting
- If Vercel prod looks empty but dev works, confirm your `PUBLIC_SUPABASE_URL` and `PUBLIC_SUPABASE_ANON_KEY` envs in Vercel **Build & Runtime**.
- Run `supabase db push` against the correct project.
- Check your auth session exists in `+page.server.ts` (redirects if not).

Enjoy!
