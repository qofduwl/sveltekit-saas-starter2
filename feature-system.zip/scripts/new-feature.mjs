#!/usr/bin/env node
/**
 * Scaffolds a new backend-connected ECharts feature in a SvelteKit + Supabase app.
 *
 * Usage:
 *   node feature-system/scripts/new-feature.mjs <chartType> <featureName> [--route "(admin)/analytics"] [--table "kpi_charts"]
 *
 * chartType: "radar" (more types can be added)
 * featureName: e.g., "kpis" (used for files, symbols, route segment)
 */
import fs from 'node:fs';
import path from 'node:path';

const args = process.argv.slice(2);
if (args.length < 2) {
  console.error('Usage: node feature-system/scripts/new-feature.mjs <chartType> <featureName> [--route "(admin)/analytics"] [--table "kpi_charts"]');
  process.exit(1);
}
const [chartType, featureNameRaw, ...rest] = args;
const featureName = featureNameRaw.toLowerCase();
const routeFlagIndex = rest.indexOf('--route');
const tableFlagIndex = rest.indexOf('--table');

const routeBase = routeFlagIndex !== -1 ? rest[routeFlagIndex + 1] : '(admin)';
const tableName = tableFlagIndex !== -1 ? rest[tableFlagIndex + 1] : `${featureName}_charts`;

const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const Feature = cap(featureName);
const timestamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14); // YYYYMMDDHHMMSS

const ROOT = process.cwd();
const TEMPLATES = path.join(ROOT, 'feature-system', 'scripts', 'templates', chartType);
if (!fs.existsSync(TEMPLATES)) {
  console.error(`Unknown chartType "${chartType}". Templates not found at ${TEMPLATES}`);
  process.exit(1);
}

function fill(t) {
  return t
    .replaceAll('%%FEATURE%%', featureName)
    .replaceAll('%%FEATURE_CAP%%', Feature)
    .replaceAll('%%TABLE%%', tableName)
    .replaceAll('%%ROUTE%%', routeBase)
    .replaceAll('%%TIMESTAMP%%', timestamp);
}

function writeOut(relPath, content) {
  const outPath = path.join(ROOT, relPath);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, content, 'utf8');
  console.log('Created', relPath);
}

// Migration
{
  const sql = fs.readFileSync(path.join(TEMPLATES, 'migration.sql.tmpl'), 'utf8');
  writeOut(`supabase/migrations/${timestamp}_add_${featureName}_table.sql`, fill(sql));
}

// Schema
{
  const schema = fs.readFileSync(path.join(TEMPLATES, 'schema.ts.tmpl'), 'utf8');
  writeOut(`src/lib/schemas/${featureName}.ts`, fill(schema));
}

// Chart option builder
{
  const opt = fs.readFileSync(path.join(TEMPLATES, 'getOption.ts.tmpl'), 'utf8');
  writeOut(`src/lib/charts/${featureName}Option.ts`, fill(opt));
}

// Form component
{
  const form = fs.readFileSync(path.join(TEMPLATES, 'Form.svelte.tmpl'), 'utf8');
  writeOut(`src/lib/components/forms/${Feature}Form.svelte`, fill(form));
}

// Route files
{
  const pageServer = fs.readFileSync(path.join(TEMPLATES, '+page.server.ts.tmpl'), 'utf8');
  writeOut(`src/routes/${routeBase}/${featureName}/(menu)/+page.server.ts`, fill(pageServer));

  const page = fs.readFileSync(path.join(TEMPLATES, '+page.svelte.tmpl'), 'utf8');
  writeOut(`src/routes/${routeBase}/${featureName}/(menu)/+page.svelte`, fill(page));
}

console.log('\nDONE: Feature scaffolded.');
console.log(`- Route: src/routes/${routeBase}/${featureName}/(menu)`);
console.log(`- Table: ${tableName}`);
console.log(`- Migration: supabase/migrations/${timestamp}_add_${featureName}_table.sql`);
console.log('\nNext:');
console.log('1) supabase db push');
console.log('2) Start dev server and visit the new page');
